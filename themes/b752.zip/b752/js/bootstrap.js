/**
 * JavaScript dependencies libraries.
 */
